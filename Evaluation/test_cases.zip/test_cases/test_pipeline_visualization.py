import pandas as pd
import pytest

from Backend.pipeline import (
    run_analysis,
    run_visualization,
)
from Backend.schema_mapper import map_business_columns


def create_test_dataframe():
    return pd.DataFrame({
        "date": pd.to_datetime([
            "2025-01-01",
            "2025-01-15",
            "2025-02-01",
            "2025-02-15",
        ]),
        "product": [
            "Laptop",
            "Monitor",
            "Laptop",
            "Monitor",
        ],
        "revenue": [
            1000,
            1500,
            1200,
            1800,
        ],
        "profit": [
            200,
            300,
            240,
            360,
        ],
        "units": [
            10,
            15,
            12,
            18,
        ],
        "profit_margin_percent": [
            20.0,
            20.0,
            20.0,
            20.0,
        ],
    })


def test_run_revenue_visualization():

    df = create_test_dataframe()

    mapping = map_business_columns(df)

    analysis = run_analysis(
        df,
        mapping,
        "revenue_trend"
    )

    figure = run_visualization(
        "revenue_trend",
        analysis
    )

    assert figure is not None
    assert len(figure.data) == 1


def test_run_profitability_visualization():

    df = create_test_dataframe()

    mapping = map_business_columns(df)

    analysis = run_analysis(
        df,
        mapping,
        "profitability"
    )

    figure = run_visualization(
        "profitability",
        analysis
    )

    assert figure is not None
    assert len(figure.data) == 1


def test_unknown_visualization_raises_error():

    with pytest.raises(
        ValueError,
        match="No visualization registered"
    ):
        run_visualization(
            "does_not_exist",
            {}
        )