from Backend.analysis_planner import select_analyses


questions = [
    "Why has our revenue declined?",

    "Which product is performing best?",

    "Why has revenue declined and which product is still performing nicely?",

    "Are returning customers contributing most of our revenue?",

    "What was the biggest monthly revenue drop?",

    "Is our marketing spending generating enough revenue?",
]


for question in questions:

    print("\n" + "=" * 70)
    print(f"QUESTION: {question}")

    try:
        plan = select_analyses(question)

        print(f"\nSUMMARY: {plan.question_summary}")

        print("\nSELECTED ANALYSES:")

        for selection in plan.analyses:
            print(
                f"  - {selection.analysis_name}"
            )

    except Exception as error:
        print(f"\nERROR: {error}")