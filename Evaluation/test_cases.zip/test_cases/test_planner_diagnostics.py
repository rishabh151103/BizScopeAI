from Backend.analysis_planner import (
    extract_requirements,
    select_tool_for_requirement,
)


QUESTIONS = [
    "What was the biggest monthly revenue drop?",
    "Is our marketing spending generating enough revenue?",
    "How are our sales changing over time?",
    "Which customer type generates the most revenue?",
    "Are there unusual values in our data?",
    "Which region has the most revenue and which has the highest profit?",
    "What is our average order value?",
    "Which category generates the most revenue?",
    "How much revenue comes from repeat customers?",
    "How variable are our revenues and profits?",
]


for i, question in enumerate(QUESTIONS, start=1):

    print("\n" + "=" * 80)
    print(f"TEST {i}")
    print(f"QUESTION: {question}")
    print("=" * 80)

    try:
        requirement_plan = extract_requirements(question)

        print("\nREQUIREMENTS:")

        for requirement in requirement_plan.requirements:

            print(f"  requirement: {requirement.requirement}")
            print(f"  metric     : {requirement.metric}")
            print(f"  dimension  : {requirement.dimension}")

            selection = select_tool_for_requirement(requirement)

            print(f"  TOOL       : {selection.analysis_name}")

    except Exception as exc:
        print(f"ERROR: {exc}")