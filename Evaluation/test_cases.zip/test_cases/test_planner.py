from Backend.analysis_planner import select_analyses


TEST_CASES = [
    # Single-intent
    {
        "question": "Why has our revenue declined?",
        "expected": ["revenue_trend"],
    },
    {
        "question": "Which product is performing best?",
        "expected": ["product_performance"],
    },
    {
        "question": "Which region generates the most profit?",
        "expected": ["regional_performance"],
    },
    {
        "question": "Are returning customers contributing most of our revenue?",
        "expected": ["customer_type"],
    },
    {
        "question": "What was the biggest monthly revenue drop?",
        "expected": ["significant_changes"],
    },
    {
        "question": "Is our marketing spending generating enough revenue?",
        "expected": ["marketing_performance"],
    },
    {
        "question": "How are our sales changing over time?",
        "expected": ["revenue_trend"],
    },
    {
        "question": "Which customer type generates the most revenue?",
        "expected": ["customer_type"],
    },
    {
        "question": "Which products have the highest profit margins?",
        "expected": ["product_performance"],
    },
    {
        "question": "Are there unusual values in our data?",
        "expected": ["outliers"],
    },

    # Multi-intent
    {
        "question": "Why has revenue declined and which product is still performing well?",
        "expected": ["revenue_trend", "product_performance"],
    },
    {
        "question": "Which region has the most revenue and which has the highest profit?",
        "expected": ["regional_performance"],
    },
    {
        "question": "How has revenue changed and which customer type contributes the most?",
        "expected": ["revenue_trend", "customer_type"],
    },

    # More specific analytical questions
    {
        "question": "What is our average order value?",
        "expected": ["order_metrics"],
    },
    {
        "question": "How profitable is each product?",
        "expected": ["product_performance"],
    },
    {
        "question": "Which category generates the most revenue?",
        "expected": ["category_performance"],
    },
    {
        "question": "How much revenue comes from repeat customers?",
        "expected": ["customer_retention"],
    },
    {
        "question": "Which customers generate the most revenue?",
        "expected": ["customer_performance"],
    },
    {
        "question": "How variable are our revenues and profits?",
        "expected": ["distribution_statistics"],
    },
    {
        "question": "Which variables are correlated with revenue?",
        "expected": ["correlations"],
    },
]


def run_benchmark():
    passed = 0
    failed = 0

    print("=" * 70)
    print("BizScopeAI Planner Benchmark")
    print("=" * 70)

    for i, case in enumerate(TEST_CASES, start=1):
        question = case["question"]
        expected = case["expected"]

        try:
            result = select_analyses(question)

            actual = [
                analysis.analysis_name
                for analysis in result.analyses
            ]

            if actual == expected:
                status = "PASS"
                passed += 1
            else:
                status = "FAIL"
                failed += 1

            print(f"\n[{status}] Test {i}")
            print(f"Question : {question}")
            print(f"Expected : {expected}")
            print(f"Actual   : {actual}")

        except Exception as exc:
            failed += 1

            print(f"\n[ERROR] Test {i}")
            print(f"Question : {question}")
            print(f"Error    : {exc}")

    total = len(TEST_CASES)

    print("\n" + "=" * 70)
    print(f"Results: {passed}/{total} passed")
    print(f"Accuracy: {passed / total * 100:.1f}%")
    print("=" * 70)


if __name__ == "__main__":
    run_benchmark()