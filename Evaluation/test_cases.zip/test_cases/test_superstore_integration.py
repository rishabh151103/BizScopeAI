from pathlib import Path

import pandas as pd

from Backend.analytics_adapter import adapt_dataset
from Backend.data_loader import (
    clean_column_names,
    load_dataset,
    preprocess_dataset,
)
from Backend.schema_mapper import map_business_columns
from Backend.analytics import analyze_revenue_trend


DATASET_PATH = Path(
    r"N:\BizScopeAI\dataset\samplesuperstore.csv"
)


def prepare_superstore():

    df = load_dataset(DATASET_PATH)

    df = clean_column_names(df)

    preprocessing_result = preprocess_dataset(df)

    cleaned_df = preprocessing_result["data"]

    mapping = map_business_columns(cleaned_df)

    adapted_df = adapt_dataset(
        cleaned_df,
        mapping
    )

    return cleaned_df, mapping, adapted_df


def test_superstore_mapping():

    _, mapping, _ = prepare_superstore()

    assert mapping.date == "order_date"
    assert mapping.revenue == "sales"
    assert mapping.profit == "profit"
    assert mapping.units == "quantity"
    assert mapping.product == "product_name"
    assert mapping.category == "category"
    assert mapping.region == "region"
    assert mapping.customer_id == "customer_id"
    assert mapping.order_id == "order_id"


def test_superstore_adapter():

    _, _, adapted_df = prepare_superstore()

    assert "date" in adapted_df.columns
    assert "revenue" in adapted_df.columns
    assert "profit" in adapted_df.columns
    assert "units" in adapted_df.columns
    assert "product" in adapted_df.columns


def test_superstore_values_are_preserved():

    cleaned_df, _, adapted_df = prepare_superstore()

    assert len(adapted_df) == len(cleaned_df)

    assert (
        adapted_df["revenue"].sum()
        == cleaned_df["sales"].sum()
    )

    assert (
        adapted_df["profit"].sum()
        == cleaned_df["profit"].sum()
    )

    assert (
        adapted_df["units"].sum()
        == cleaned_df["quantity"].sum()
    )


def test_superstore_revenue_analysis():

    _, _, adapted_df = prepare_superstore()

    result = analyze_revenue_trend(
        adapted_df
    )

    assert "monthly_revenue" in result
    assert "overall_change_percent" in result
    assert "trend" in result

    assert not result["monthly_revenue"].empty