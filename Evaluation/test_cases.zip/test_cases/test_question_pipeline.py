import io

import pandas as pd

from Backend.pipeline import investigate_business_question


def create_test_csv():
    df = pd.DataFrame({
        "order_id": [
            "O1",
            "O2",
            "O3",
            "O4",
            "O5",
            "O6",
        ],
        "date": [
            "2025-01-01",
            "2025-01-15",
            "2025-02-01",
            "2025-02-15",
            "2025-03-01",
            "2025-03-15",
        ],
        "customer_id": [
            "C1",
            "C2",
            "C1",
            "C3",
            "C1",
            "C2",
        ],
        "product": [
            "Laptop",
            "Monitor",
            "Laptop",
            "Monitor",
            "Laptop",
            "Monitor",
        ],
        "category": [
            "Electronics",
            "Electronics",
            "Electronics",
            "Electronics",
            "Electronics",
            "Electronics",
        ],
        "region": [
            "North",
            "South",
            "North",
            "South",
            "North",
            "South",
        ],
        "customer_type": [
            "New",
            "Returning",
            "Returning",
            "New",
            "Returning",
            "Returning",
        ],
        "units": [
            2,
            3,
            1,
            2,
            4,
            3,
        ],
        "unit_price": [
            1000,
            500,
            1000,
            500,
            1000,
            500,
        ],
        "revenue": [
            2000,
            1500,
            1000,
            1000,
            4000,
            1500,
        ],
        "cost": [
            1600,
            1200,
            800,
            800,
            3200,
            1200,
        ],
        "marketing_spend": [
            100,
            100,
            100,
            100,
            100,
            100,
        ],
        "profit": [
            400,
            300,
            200,
            200,
            800,
            300,
        ],
        "profit_margin_percent": [
            20,
            20,
            20,
            20,
            20,
            20,
        ],
    })

    csv_bytes = df.to_csv(index=False).encode()

    return io.BytesIO(csv_bytes)


def test_question_pipeline_revenue():

    uploaded_file = create_test_csv()

    result = investigate_business_question(
        uploaded_file,
        "How has our revenue changed over time?",
        visualization=True,
    )

    assert result["analysis_names"] == [
        "revenue_trend"
    ]

    assert "revenue_trend" in result["analyses"]

    analysis = result["analyses"]["revenue_trend"]

    assert "monthly_revenue" in analysis

    assert "overall_change_percent" in analysis

    assert "trend" in analysis


def test_question_pipeline_customer_performance():

    uploaded_file = create_test_csv()

    result = investigate_business_question(
        uploaded_file,
        "Which customers generate the most revenue?",
        visualization=True,
    )

    assert result["analysis_names"] == [
        "customer_performance"
    ]

    assert "customer_performance" in result["analyses"]

    analysis = result["analyses"][
        "customer_performance"
    ]

    assert "customer_analysis" in analysis

    assert "highest_revenue_customer" in analysis