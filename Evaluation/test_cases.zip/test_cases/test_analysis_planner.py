import pytest

from Backend.analysis_planner import select_analyses
from Backend.analytics_registry import ANALYTICS_REGISTRY
from Backend.schemas import AnalysisPlan


def get_selected_names(plan):
    return {
        selection.analysis_name
        for selection in plan.analyses
    }


def test_analysis_planner_returns_valid_plan():

    question = (
        "Why has our revenue declined and "
        "which product is still performing nicely?"
    )

    plan = select_analyses(question)

    assert isinstance(plan, AnalysisPlan)

    assert plan.question_summary.strip()

    assert 1 <= len(plan.analyses) <= 5

    for selection in plan.analyses:

        assert selection.analysis_name in ANALYTICS_REGISTRY

        assert selection.requirement is not None
        assert selection.requirement.requirement.strip()


def test_analysis_selection_preserves_requirement():

    question = "Why has our revenue declined?"

    plan = select_analyses(question)

    assert len(plan.analyses) >= 1

    for selection in plan.analyses:

        assert selection.requirement is not None
        assert selection.requirement.requirement.strip()        


def test_revenue_question_selects_revenue_analysis():

    question = "Why has our revenue declined?"

    plan = select_analyses(question)

    selected_names = get_selected_names(plan)

    assert "revenue_trend" in selected_names


def test_product_question_selects_product_analysis():

    question = "Which product is performing best?"

    plan = select_analyses(question)

    selected_names = get_selected_names(plan)

    assert "product_performance" in selected_names


def test_multi_intent_question_selects_multiple_analyses():

    question = (
        "Why has revenue declined and "
        "which product is still performing nicely?"
    )

    plan = select_analyses(question)

    selected_names = get_selected_names(plan)

    assert "revenue_trend" in selected_names
    assert "product_performance" in selected_names


def test_empty_question_is_rejected():

    with pytest.raises(ValueError):
        select_analyses("")


def test_analysis_planner_extracts_comparison_period():
    question = (
        "How did product revenue change "
        "between January and February 2025?"
    )

    plan = select_analyses(question)

    assert len(plan.analyses) >= 1

    requirement = plan.analyses[0].requirement

    assert requirement.metric == "revenue"
    assert requirement.dimension == "product"
    assert requirement.operation == "change"
    assert requirement.start_month == "2025-01"
    assert requirement.end_month == "2025-02"        