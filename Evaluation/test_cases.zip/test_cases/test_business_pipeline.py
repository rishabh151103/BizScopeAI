import io

from Backend.pipeline import investigate_business_question


def create_csv():

    return io.StringIO(
        """date,product,revenue,profit,units,profit_margin_percent
2025-01-01,Laptop,1000,200,10,20
2025-01-15,Monitor,1500,300,15,20
2025-02-01,Laptop,1200,240,12,20
2025-02-15,Monitor,1800,360,18,20
"""
    )


def test_business_pipeline():

    uploaded_file = create_csv()
    uploaded_file.name = "test.csv"

    result = investigate_business_question(
        uploaded_file,
        "revenue_trend"
    )

    assert result["analysis_name"] == "revenue_trend"

    assert result["data"]["rows"] == 4

    assert result["analysis"] is not None

    assert "monthly_revenue" in result["analysis"]

    assert result["visualization"] is not None


def test_business_pipeline_without_visualization():

    uploaded_file = create_csv()
    uploaded_file.name = "test.csv"

    result = investigate_business_question(
        uploaded_file,
        "revenue_trend",
        visualization=False
    )

    assert result["analysis"] is not None

    assert result["visualization"] is None